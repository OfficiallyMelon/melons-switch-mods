https://github.com/OfficiallyMelon/melons-switch-mods
@OfficiallyMelon on discord